const recognition = new webkitSpeechRecognition() || new SpeechRecognition();
recognition.continuous = false;
recognition.interimResults = false;

const searchInput = document.getElementById('searchInput');
const voiceButton = document.getElementById('voiceButton');
const searchResults = document.getElementById('searchResults');

voiceButton.addEventListener('click', () => {
    recognition.start();
});

recognition.onresult = (event) => {
    const result = event.results[0][0].transcript;
    searchInput.value = result;
    searchResults.innerHTML = <p>You said: "${result}"</p>;
};
